<?php

die(':)');